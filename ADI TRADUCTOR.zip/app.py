from tkinter import *
from tkinter import ttk, messagebox
import pandas as pd

def lire_fichier_csv(path):
    df = pd.read_csv(path, encoding="utf-8", skiprows=3)
    df = df.loc[:, ["FR", "ADI", "Origine"]]
    return df.to_dict(orient="records")


tradd = lire_fichier_csv("adi.csv")

root = Tk()
frm = ttk.Frame(root, padding=10)
frm.grid()
root.title("ADI TRADUCTOR")

def trad():
    tw = wordtrad.get().strip()  
    for p in tradd:
        if str(p["FR"]).strip().lower() == tw.lower():
            adi = p["ADI"]
            info= p["Origine"]
            messagebox.showinfo("Traduction", f"{tw} → {adi}\nInformation : {info}")
            break
    else:
        messagebox.showerror("Erreur", f"'{tw}' n'existe pas dans le dictionnaire ou il y'a une faute (Veillez à mettre une majuscule)")

ttk.Label(frm, text="Traducteur Français → Âde").grid(column=0, row=0, columnspan=2, pady=5)
wordtrad = StringVar()
ttk.Entry(frm, textvariable=wordtrad, width=30).grid(row=1, column=0, padx=5, pady=5)
ttk.Button(frm, text="Traduire", command=trad).grid(row=1, column=1, padx=5)
ttk.Button(frm, text="Quitter", command=root.destroy).grid(column=0, row=2, columnspan=2, pady=10)

root.mainloop()
